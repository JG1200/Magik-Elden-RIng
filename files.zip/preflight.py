import json,glob,sys
sheets={}
for f in sorted(glob.glob("*.json")):
    d=json.load(open(f)); sheets[d["sheet"]]=d["rows"]
ids={r["id"] for rows in sheets.values() for r in rows}
refs={"darkchild_id","base_ability","ability_id"}
bad=0
for s,rows in sheets.items():
    for r in rows:
        for k,v in r.items():
            if v is None and not (k=="darkchild_id"):
                print(f"UNFILLED {s}.{r['id']}.{k}"); bad+=1
            if k in refs and v is not None and v not in ids:
                print(f"UNRESOLVED {s}.{r['id']}.{k} -> {v}"); bad+=1
            if k=="verified" and v is False:
                print(f"UNVERIFIED {s}.{r['id']}"); bad+=1
print("PREFLIGHT",("CLEAN" if bad==0 else f"{bad} issues"))
sys.exit(1 if bad else 0)
